#!/usr/bin/env node

import { execSync, execFileSync, spawn } from 'child_process'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { createCommand } from './create.js'
import { start as startCorsProxy } from './cors-proxy-server.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const libraryRoot = path.dirname(__dirname)

const commands = {
  lint: {
    description: 'Run ESLint with shared configuration',
    handler: lintCommand,
  },
  dev: {
    description: 'Start Vite development server',
    handler: devCommand,
  },
  build: {
    description: 'Build application for production',
    handler: buildCommand,
  },
  'build:dev': {
    description: 'Build application in development mode with watch',
    handler: buildDevCommand,
  },
  'type-check': {
    description: 'Run TypeScript type checking',
    handler: typeCheckCommand,
  },
  screenshots: {
    description: 'Capture screenshots at all supported resolutions',
    handler: screenshotsCommand,
  },
  'cors-proxy': {
    description: 'Start the CORS proxy server for local development',
    handler: startCorsProxy,
  },
  create: {
    description:
      'Initialize a scaffolded Edge App (replaces template placeholders)',
    handler: createCommand,
  },
}

function resolveBin(name) {
  const appBin = path.resolve(process.cwd(), 'node_modules', '.bin', name)
  return fs.existsSync(appBin)
    ? appBin
    : path.resolve(libraryRoot, 'node_modules', '.bin', name)
}

function getNodePath() {
  const libraryNodeModules = path.resolve(libraryRoot, 'node_modules')
  const existingNodePath = process.env.NODE_PATH || ''
  return existingNodePath
    ? `${libraryNodeModules}${path.delimiter}${existingNodePath}`
    : libraryNodeModules
}

function setupSignalHandlers(child) {
  const handleSignal = (signal) => {
    child.kill(signal)
    child.on('exit', () => process.exit(0))
  }
  process.on('SIGINT', () => handleSignal('SIGINT'))
  process.on('SIGTERM', () => handleSignal('SIGTERM'))
}

function spawnWithSignalHandling(command, args, errorMessage) {
  const child = spawn(command, args, {
    stdio: 'inherit',
    cwd: process.cwd(),
    shell: process.platform === 'win32',
    env: {
      ...process.env,
      NODE_PATH: getNodePath(),
    },
  })

  child.on('error', (err) => {
    console.error(errorMessage, err)
    process.exit(1)
  })

  setupSignalHandlers(child)
}

function getVitePaths() {
  return {
    viteBin: resolveBin('vite'),
    configPath: path.resolve(libraryRoot, 'vite.config.ts'),
  }
}

async function lintCommand(args) {
  try {
    const eslintBin = resolveBin('eslint')

    const eslintArgs = [
      '--config',
      path.resolve(libraryRoot, 'eslint.config.ts'),
      '.',
      ...args,
    ]

    execSync(
      `"${eslintBin}" ${eslintArgs.map((arg) => `"${arg}"`).join(' ')}`,
      {
        stdio: 'inherit',
        cwd: process.cwd(),
      },
    )
  } catch {
    process.exit(1)
  }
}

async function devCommand(args) {
  try {
    const { viteBin, configPath } = getVitePaths()
    const viteArgs = ['--config', configPath, ...args]

    spawnWithSignalHandling(viteBin, viteArgs, 'Failed to start dev server:')
  } catch {
    process.exit(1)
  }
}

async function buildCommand(args) {
  try {
    const { viteBin, configPath } = getVitePaths()
    const sourcemaps = args.includes('--sourcemaps')
    const filteredArgs = args.filter((arg) => arg !== '--sourcemaps')
    const viteArgs = [
      'build',
      '--config',
      configPath,
      ...(sourcemaps ? ['--sourcemap'] : []),
      ...filteredArgs,
    ]

    execFileSync(viteBin, viteArgs, {
      stdio: 'inherit',
      cwd: process.cwd(),
      env: {
        ...process.env,
        NODE_PATH: getNodePath(),
      },
    })
  } catch {
    process.exit(1)
  }
}

async function buildDevCommand(args) {
  try {
    const { viteBin, configPath } = getVitePaths()
    const viteArgs = [
      'build',
      '--watch',
      '--sourcemap',
      '--config',
      configPath,
      ...args,
    ]

    spawnWithSignalHandling(viteBin, viteArgs, 'Failed to start build process:')
  } catch {
    process.exit(1)
  }
}

async function typeCheckCommand(args) {
  try {
    const tscBin = resolveBin('tsc')

    const tscArgs = [
      '--noEmit',
      '--project',
      path.resolve(process.cwd(), 'tsconfig.json'),
      ...args,
    ]

    execSync(`"${tscBin}" ${tscArgs.map((arg) => `"${arg}"`).join(' ')}`, {
      stdio: 'inherit',
      cwd: process.cwd(),
    })
  } catch {
    process.exit(1)
  }
}

async function convertPngsToWebP(screenshotsDir) {
  const { default: sharp } = await import('sharp')
  const pngFiles = fs
    .readdirSync(screenshotsDir)
    .filter((f) => f.endsWith('.png'))

  for (const file of pngFiles) {
    const pngPath = path.join(screenshotsDir, file)
    const webpPath = path.join(screenshotsDir, file.replace('.png', '.webp'))
    await sharp(pngPath).webp().toFile(webpPath)
    fs.unlinkSync(pngPath)
  }
}

async function screenshotsCommand(_args) {
  try {
    const playwrightBin = resolveBin('playwright')
    const playwrightConfig = path.resolve(
      libraryRoot,
      'configs',
      'playwright.js',
    )
    execSync(`"${playwrightBin}" test --config "${playwrightConfig}"`, {
      stdio: 'inherit',
      cwd: process.cwd(),
      env: {
        ...process.env,
        NODE_PATH: getNodePath(),
      },
    })

    const screenshotsDir = path.resolve(process.cwd(), 'screenshots')
    if (fs.existsSync(screenshotsDir)) {
      await convertPngsToWebP(screenshotsDir)
    }
  } catch (error) {
    console.error(
      'Failed to run screenshot tests. Ensure `@playwright/test` is installed and the Playwright config file exists.',
    )
    if (error instanceof Error && error.message) {
      console.error(error.message)
    }
    process.exit(1)
  }
}

export async function run() {
  const args = process.argv.slice(2)

  if (args.length === 0) {
    printHelp()
    process.exit(1)
  }

  const cmd = args[0]
  const cmdArgs = args.slice(1)

  if (cmd === '--help' || cmd === '-h') {
    printHelp()
    process.exit(0)
  }

  if (!(cmd in commands)) {
    console.error(`Unknown command: ${cmd}`)
    printHelp()
    process.exit(1)
  }

  const handler = commands[cmd].handler
  await handler(cmdArgs)
}

function printHelp() {
  console.log(`
edge-apps-scripts - Shared tooling for Screenly Edge Apps

Usage: edge-apps-scripts <command> [options]

Commands:
${Object.entries(commands)
  .map(([name, { description }]) => `  ${name.padEnd(12)} ${description}`)
  .join('\n')}

Options:
  --help, -h   Show this help message
`)
}
